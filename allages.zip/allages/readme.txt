=== All_Ages  ===
Contributors: @mattkosoy
Tags: vimeo, plugin
Requires at least: 2.9.2
Tested up to: 2.9.2
Stable tag: 0.4

A plugin to grab and save a list of videos from Viemo. 

== Description ==
This will create a page for each video that a particular user has uploaded to vim, and associates it to a parent page of the admin's choice.  Also, this plugin saves all vimeo api data to the local db, and associates it to these dynamic pages as wp post_meta data.  
 
== Installation ==

1. Upload the contents of 'allages.zip' to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==
= Forthcoming =

== Screenshots ==
= Forthcoming =

== Changelog ==
0.4 - added custom page template for public facing output
0.3 - added in support for wpdb->prefix
0.2 - updated to support php 4
0.1 - added plugin admin screens, and enabled automatic importing of vimeo data into wpdb.
